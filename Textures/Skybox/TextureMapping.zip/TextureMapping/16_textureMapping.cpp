/*
  Texture Mapping
  Copyright:   Version 1.0
  Author:      André Ferreira Martins
               Bruno Marcos Pinheiro da Silva
  Last Update: 31/10/2017
  Release:     31/10/2017
  Description: Simple Texture Mapping project
*/

#include <GL/glut.h>
#include <GL/glext.h>
#include <iostream>
#include "glcTexture.h"
#include "math.h"

using namespace std;

// Aqui é criada a referência ao objeto que gerenciará as texturas
glcTexture *textureManager;
int selected = 0;
int object = 1;
float width, height;
float zoom = 1.8f;
float pan[2]  = {0.0f, 0.0f};
bool fullScreen = false;
float rotationX = 0.0, rotationY = 0.0;
int   last_x, last_y;
int window;

bool wrappingMode = 1;
bool magMode = 1;
bool minMode = 1;
int colorMode = 0;
float tiles = 1.0;

void DrawCircle(float radius, int slices)
{
    textureManager->Bind(5);
    glBegin(GL_POLYGON);
        for (int i = 0; i < slices; ++i)
        {
            float angle = (i / (float)slices) * 2 * M_PI;
            glTexCoord2f((cos(angle) + 1) * 0.5f, (sin(angle) + 1) * 0.5f);
            glVertex3f(cos(angle) * radius, 0, sin(angle) * radius);
        }
    glEnd();
}
void DrawCylinder(float radius, float length, int slices)
{
    glNormal3f(0, 1, 0);

    glPushMatrix();
        glTranslatef(0, length / 2, 0);
        DrawCircle(radius, slices);
    glPopMatrix();

    glPushMatrix();
        glRotatef(180, 0, 0, 1);
        glTranslatef(0, length / 2, 0);
        DrawCircle(radius, slices);
    glPopMatrix();

    textureManager->Bind(4);
    glBegin(GL_TRIANGLE_STRIP);
        for (int i = 0; i <= slices; ++i)
        {
            float angle = (i / (float)slices) * 2 * M_PI;
            glNormal3f(cos(angle), 0, sin(angle));
            glTexCoord2f((angle / (2 * M_PI)), 1.0f);
            glVertex3f(cos(angle) * radius, length / 2, sin(angle) * radius);
            glTexCoord2f((angle / (2 * M_PI)), 0.0f);
            glVertex3f(cos(angle) * radius, -length / 2, sin(angle) * radius);
        }
    glEnd();
}

void DrawTorus(float radius, float middleRadius, int slices, int stacks)
{
    glPushMatrix();
        for (int j = 0; j < stacks; ++j)
        {
            float middleAngle1 = (j / (float)stacks) * 2 * M_PI;
            float middleAngle2 = ((j + 1) / (float)stacks) * 2 * M_PI;
            float dirX1 = cos(middleAngle1);
            float dirZ1 = sin(middleAngle1);
            float dirX2 = cos(middleAngle2);
            float dirZ2 = sin(middleAngle2);

            glBegin(GL_TRIANGLE_STRIP);
                for (int i = 0; i <= slices; ++i)
                {
                    float angle = (i / (float)slices) * 2 * M_PI;
                    float center = cos(angle) * radius + middleRadius;
                    glVertex3f(dirX1 * center, sin(angle) * radius, dirZ1 * center);
                    glVertex3f(dirX2 * center, sin(angle) * radius, dirZ2 * center);
                }
            glEnd();
        }
    glPopMatrix();
}

void DrawQuad(int l)
{
    glBegin(GL_QUADS);
        glNormal3f(0.0, 0.0, 1.0);
        glTexCoord2f(0.0, 0.0);
        glVertex3f(-l, -l, l);

        glTexCoord2f(tiles, 0.0f);
        glVertex3f(l, -l, l);

        glTexCoord2f(tiles, tiles);
        glVertex3f(l, l, l);

        glTexCoord2f(0.0f, tiles);
        glVertex3f(-l, l, l);
    glEnd();
}

// Como as imagens são lidas a partir do canto superior direito, temos que inverter as coordenadas 'u' e 'v'
void display(void)
{
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   gluPerspective(60, width/height, 0.1, 100);

   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();

   gluLookAt(pan[0], pan[1], zoom, pan[0], pan[1], 0.0, 0.0, 1.0, 0.0);
   // Seleciona a textura corrente
   textureManager->Bind(selected);
   float aspectRatio = textureManager->GetAspectRatio(selected);

   // Calculo abaixo funciona apenas se textura estiver centralizada na origem
   float l = 1.0f;

   glPushMatrix();
   glRotatef( rotationY, 0.0, 1.0, 0.0 );
   glRotatef( rotationX, 1.0, 0.0, 0.0 );

   if(object == 1)
   {
      DrawQuad(l);

      glPushMatrix();
      glRotatef(90, 0, 1, 0);
      DrawQuad(l);
      glPopMatrix();

      glPushMatrix();
      glRotatef(180, 0, 1, 0);
      DrawQuad(l);
      glPopMatrix();

      glPushMatrix();
      glRotatef(270, 0, 1, 0);
      DrawQuad(l);
      glPopMatrix();

      glPushMatrix();
      glRotatef(90, 1, 0, 0);
      DrawQuad(l);
      glPopMatrix();

      glPushMatrix();
      glRotatef(270, 1, 0, 0);
      DrawQuad(l);
      glPopMatrix();
   }
   else // object == 2
   {
       DrawCylinder(1, 2, 50);
   }
   glPopMatrix();

   glutSwapBuffers();

   // Desabilita o uso de texturas
   textureManager->Disable();
}

void resizeWindow(int w, int h)
{
   width = w;
   height = h;
   glViewport(0, 0, w, h);
}

void changeWindowTitle(char* name)
{
   glutSetWindow(window); // Set main window as current
   glutSetWindowTitle(name); // change title
}

void keyboard (unsigned char key, int x, int y)
{
   if(isdigit(key))
   {
      int val = atoi((const char *) &key);
      if(val > 0 && val <= textureManager->GetNumberOfTextures() )
         selected = val-1;
   }
   switch (key)
   {
      case 27:
         exit(0);
      break;
      case '+':
         if(zoom>=0.3)  zoom-=0.1f;
      break;
      case '-':
         if(zoom<=20.0) zoom+=0.1f;
      break;
      case 'w': // wrapping modes
         wrappingMode = !wrappingMode;
         if(wrappingMode)
         {
            textureManager->SetWrappingMode(GL_REPEAT);
            changeWindowTitle( (char *) "Wrapping Mode = GL_REPEAT");
         }
         else
         {
            textureManager->SetWrappingMode(GL_CLAMP);
            changeWindowTitle( (char *) "Wrapping Mode = GL_CLAMP");
         }
         textureManager->Update();
      break;
      case 'm': // minificação
         minMode = !minMode;
         if(minMode)
         {
            textureManager->SetMinFilterMode(GL_LINEAR);
            changeWindowTitle( (char *) "Minification Mode = GL_LINEAR");
         }
         else
         {
            textureManager->SetMinFilterMode(GL_NEAREST);
            changeWindowTitle( (char *) "Minification Mode = GL_NEAREST");
         }
         textureManager->Update();
      break;
      case 'g': // magnificação
         magMode = !magMode;
         if(magMode)
         {
            textureManager->SetMagFilterMode(GL_NEAREST);
            changeWindowTitle( (char *) "Magnification Mode = GL_NEAREST");
         }
         else
         {
            textureManager->SetMagFilterMode(GL_LINEAR);
            changeWindowTitle( (char *) "Magnification Mode = GL_LINEAR");
         }
         textureManager->Update();
      break;
      case 'c': // Color Mode
         colorMode++;
         if(colorMode > 2) colorMode = 0;
         switch(colorMode)
         {
            case 0:
               textureManager->SetColorMode(GL_MODULATE);
               changeWindowTitle( (char *) "Color Mode = GL_MODULATE");
            break;
            case 1:
               textureManager->SetColorMode(GL_REPLACE);
               changeWindowTitle( (char *) "Color Mode = GL_REPLACE");
            break;
            case 2:
               textureManager->SetColorMode(GL_BLEND);
               changeWindowTitle( (char *) "Color Mode = GL_BLEND");
            break;
         }
         textureManager->Update();
      break;
      case 't': // Increase Texture Tiles
			tiles++;
		break;
      case 'T': // Decrease Texture Tiles
			if(tiles>1.0f) tiles--;
		break;
   }
   glutPostRedisplay();
}

void specialKeys(int key, int x, int y)
{
   float f = 0.05;
   switch(key)
   {
   case GLUT_KEY_UP:
      pan[1]+=f;
      break;
   case GLUT_KEY_DOWN:
      pan[1]-=f;
      break;
   case GLUT_KEY_LEFT:
      pan[0]-=f;
      break;
   case GLUT_KEY_RIGHT:
      pan[0]+=f;
      break;
   case GLUT_KEY_F11:
      (!fullScreen) ? glutFullScreen() : glutReshapeWindow(800, 600);
      //glutPositionWindow(100, 100);
      fullScreen = !fullScreen;
      break;
   case GLUT_KEY_F1:
      object = 1;
      break;
   case GLUT_KEY_F2:
      object = 2;
      break;
   }
   glutPostRedisplay();
}


void init(void)
{
   glClearColor (0.5, 0.5, 0.5, 0.0);
   glShadeModel (GL_SMOOTH);
   glEnable(GL_DEPTH_TEST);               // Habilita Z-buffer
   glEnable(GL_LIGHTING);                 // Habilita luz
   glEnable(GL_LIGHT0);                   // habilita luz 0

	glEnable(GL_ALPHA_TEST); // O alpha test descarta fragmentos dependendo de uma comparação (abaixo)
   glAlphaFunc(GL_GREATER, 0.5); // Info: https://www.opengl.org/sdk/docs/man2/xhtml/glAlphaFunc.xml

   glEnable(GL_BLEND);
   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); // https://www.opengl.org/sdk/docs/man/html/glBlendFunc.xhtml

   // Cor da fonte de luz (RGBA)
   GLfloat cor_luz[]     = { 1.0, 1.0, 1.0, 1.0};
   GLfloat posicao_luz[] = { 0.0, 0.0, 10.0, 1.0};

   // Define parametros da luz
   glLightfv(GL_LIGHT0, GL_AMBIENT, cor_luz);
   glLightfv(GL_LIGHT0, GL_DIFFUSE, cor_luz);
   glLightfv(GL_LIGHT0, GL_SPECULAR, cor_luz);
   glLightfv(GL_LIGHT0, GL_POSITION, posicao_luz);

   // Essa é a principal parte deste exemplo
   textureManager = new glcTexture();            // Criação do arquivo que irá gerenciar as texturas
   textureManager->SetNumberOfTextures(6);       // Estabelece o número de texturas que será utilizado
   textureManager->SetWrappingMode(GL_REPEAT);

   textureManager->CreateTexture("../data/marble.png", 0); // Para testar magnificação, usar a imagem marble128
   textureManager->CreateTexture("../data/carbon.png", 1); // Textura transparente, não sendo múltipla de zero
   textureManager->CreateTexture("../data/fishermen.png", 2); // Textura transparente, não sendo múltipla de zero
   textureManager->CreateTexture("../data/paper.png", 3);
   textureManager->CreateTexture("../data/wood.png", 4);
   textureManager->CreateTexture("../data/woodtop.png", 5);
}

// Motion callback//glcTexture *texture;
void motion(int x, int y )
{
   rotationX += (float) (y - last_y);
   rotationY += (float) (x - last_x);

   last_x = x;
   last_y = y;
}

// Mouse callback
void mouse(int button, int state, int x, int y)
{
   if ( button == GLUT_LEFT_BUTTON && state == GLUT_DOWN )
   {
      last_x = x;
      last_y = y;
   }
   if(button == 3) // Scroll up
   {
      if(zoom>=0.3)  zoom-=0.04f;
   }
   if(button==4)   // Scroll down
   {
      if(zoom<=20.0) zoom+=0.04f;
   }
}

void idle ()
{
   glutPostRedisplay();
}


void printOpenGLVersion()
{
   cout << "\nDados do OpenGL instalado neste sistema operacional:" << endl;
   char *vendor  = (char * ) glGetString(GL_VENDOR);
   char *version = (char * ) glGetString(GL_VERSION);
   char *render  = (char * ) glGetString(GL_RENDERER);
   cout << "   Vendor:   " << vendor   << endl;
   cout << "   Version:  " << version  << endl;
  cout << "   Renderer: " << render   << endl;
   if(version[0] == '1')
   {
      cout << "\nAviso: A biblioteca pode nao funcionar corretamente (versao antiga do OpenGL).";
      cout << "\n       Maiores detalhes nas notas do arquivo \"README_FIRST.txt\".\n";
   }
   cout << endl;
}

int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
   glutInitWindowSize(800, 600);
   glutInitWindowPosition(100, 100);
   window = glutCreateWindow(argv[0]);

   init();
   printOpenGLVersion();
   cout << "\n------------------------------------------------------------\n" << endl;
   cout << "Instrucoes: " << endl;
   cout << " * Modifique as texturas pressionando as teclas de um 1 a " << textureManager->GetNumberOfTextures() << ";" << endl;
   cout << " * Pressione F1 e F2 para mudar os objetos;" << endl;
   cout << " * Teclas '+' e '-' fazem zoom;" << endl;
   cout << " * Teclas 'w' para alternar entre os \"Wrapping modes\";" << endl;
   cout << " * Teclas 'm' para alternar entre os modos do filtro de minificação;" << endl;
   cout << " * Teclas 'g' para alternar entre os modos do filtro de magnificação;" << endl;
   cout << " * Teclas 'c' para alternar entre os modos de cor de textura;" << endl;
   cout << " * Teclas 't' ou 'T' para aumentar/diminuir o tamanho da coordenada de textura (em 2D);" << endl;
   cout << " * Direcionais do teclado movem a camera (pan);" << endl;
   cout << " * Mouse rotaciona o objeto;" << endl;
   cout << " * Pressione F11 para ligar e desligar modo FullScreen;" << endl;

   glutDisplayFunc(display);
   glutReshapeFunc(resizeWindow);
   glutKeyboardFunc(keyboard);
   glutSpecialFunc( specialKeys );
   glutMouseFunc( mouse );
   glutMotionFunc( motion );
   glutIdleFunc(idle);
   glutMainLoop();
   return 0;
}
