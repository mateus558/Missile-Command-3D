git add -A
git commit
git push origin master
